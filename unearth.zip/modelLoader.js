// ============================================
// MODEL LOADER - With size normalization
// ============================================

import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import * as THREE from 'three';

// Maximum size for any artifact (in world units)
const MAX_ARTIFACT_SIZE = 0.8;

// Model paths mapped to artifact types
export const ARTIFACT_MODELS = {
    // ========== EGYPT ==========
    pyramid: './public/models/pyramid_and_the_sphinx.glb',
    sphinx: './public/models/the_great_sphinx_of_giza_-_egypt.glb',
    ankh: './public/models/ankh_asset.glb',
    scarab: './public/models/giant_sculpture_of_a_scarab_beetle.glb',
    pharaoh_mask: './public/models/tutankhamun_gold_mask.glb',

    // ========== GREECE ==========
    column: './public/models/ionic_column.glb',
    amphora: './public/models/ancient_greek_amphora.glb',
    helmet: './public/models/pbr_corinthian_helmet.glb',
    pottery: './public/models/ancient_greek_pottery.glb',
    coin_greek: './public/models/greek_bronze_coin.glb',

    // ========== CHINA ==========
    dragon: './public/models/chinese_dragon.glb',
    pagoda: './public/models/chinese_pagoda_low_poly.glb',
    terracotta: './public/models/terracotta_warrior_3_3dst40.glb',
    terracotta2: './public/models/terracotta_warrior_4_-_high_resolution.glb',
    temple: './public/models/chinese_temple.glb',

    // ========== MEXICO ==========
    aztec_calendar: './public/models/aztec_calendar_stone_cast.glb',
    pyramid_mayan: './public/models/mayan_pyramid.glb',
    mictlantecuhtli: './public/models/figure_of_mictlantecuhtli.glb',
    sun_stone: './public/models/aztec_sun_stone.glb',
    chichen_itza: './public/models/chichen_itza_pyramid_3d_reconstruction.glb',

    // ========== JAPAN ==========
    torii: './public/models/torii_gate.glb',
    torii_abandoned: './public/models/abandoned_torii_gate.glb',
    katana: './public/models/katana._samurai_sword._blender_sword._simple..glb',
    daruma: './public/models/daruma.glb'
};

class ModelLoader {
    constructor() {
        this.loader = new GLTFLoader();
        this.cache = new Map();
    }

    async loadModel(artifactType) {
        const path = ARTIFACT_MODELS[artifactType];
        
        if (!path) {
            console.warn(`No model path for: ${artifactType}`);
            return null;
        }

        // Check cache first
        if (this.cache.has(artifactType)) {
            console.log(`Using cached model for: ${artifactType}`);
            return this.cache.get(artifactType).clone();
        }

        try {
            console.log(`Loading model: ${artifactType} from ${path}`);
            const gltf = await this.loader.loadAsync(path);
            const scene = gltf.scene;
            
            // Count meshes for debugging
            let meshCount = 0;
            scene.traverse((child) => {
                if (child.isMesh) {
                    meshCount++;
                    child.castShadow = true;
                    child.receiveShadow = true;
                }
            });
            console.log(`  -> Found ${meshCount} meshes in ${artifactType}`);
            
            if (meshCount === 0) {
                console.warn(`  -> No meshes found in ${artifactType}!`);
                return null;
            }

            // Normalize size
            const box = new THREE.Box3().setFromObject(scene);
            const size = new THREE.Vector3();
            box.getSize(size);
            const maxDim = Math.max(size.x, size.y, size.z);
            
            if (maxDim > 0) {
                const scale = MAX_ARTIFACT_SIZE / maxDim;
                scene.scale.multiplyScalar(scale);
            }

            // Recalculate bounds after scaling
            box.setFromObject(scene);
            const center = new THREE.Vector3();
            box.getCenter(center);
            const min = new THREE.Vector3();
            box.getMin(min);

            // Center horizontally, align bottom to y=0
            scene.position.x -= center.x;
            scene.position.z -= center.z;
            scene.position.y -= min.y;

            // Wrap in a group
            const wrapper = new THREE.Group();
            wrapper.add(scene);
            
            // Cache it
            this.cache.set(artifactType, wrapper);
            console.log(`  -> Cached ${artifactType} successfully`);

            // Return a clone
            return wrapper.clone();
            
        } catch (error) {
            console.error(`Failed to load ${artifactType}:`, error);
            return null;
        }
    }

    async preloadAll() {
        const types = Object.keys(ARTIFACT_MODELS);
        console.log(`Preloading ${types.length} models...`);

        let loaded = 0;
        let failed = 0;

        for (const type of types) {
            const model = await this.loadModel(type);
            if (model) {
                loaded++;
            } else {
                failed++;
            }
        }

        console.log(`Preload complete: ${loaded} loaded, ${failed} failed`);
    }
}

export const modelLoader = new ModelLoader();
