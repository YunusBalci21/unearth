import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { modelLoader } from './modelLoader.js';

// ============================================
// GAME CONFIGURATION
// ============================================

const COUNTRIES = [
    {
        name: 'Egypt',
        terrain: {
            color: 0xd4a574,
            roughness: 0.9,
            type: 'sand'
        },
        artifacts: ['pyramid', 'sphinx', 'ankh', 'scarab', 'pharaoh_mask']
    },
    {
        name: 'Greece',
        terrain: {
            color: 0x8b7355,
            roughness: 0.8,
            type: 'dirt'
        },
        artifacts: ['column', 'amphora', 'helmet', 'pottery', 'coin_greek']
    },
    {
        name: 'China',
        terrain: {
            color: 0x654321,
            roughness: 0.7,
            type: 'soil'
        },
        artifacts: ['dragon', 'pagoda', 'terracotta', 'terracotta2', 'temple']
    },
    {
        name: 'Mexico',
        terrain: {
            color: 0xc2b280,
            roughness: 0.85,
            type: 'sand'
        },
        artifacts: ['aztec_calendar', 'pyramid_mayan', 'mictlantecuhtli', 'sun_stone', 'chichen_itza']
    },
    {
        name: 'Japan',
        terrain: {
            color: 0x3d2817,
            roughness: 0.6,
            type: 'soil'
        },
        artifacts: ['torii', 'torii_abandoned', 'katana', 'daruma']
    }
];

const ALL_COUNTRIES = [
    'Afghanistan', 'Albania', 'Algeria', 'Argentina', 'Australia', 'Austria',
    'Belgium', 'Brazil', 'Cambodia', 'Canada', 'Chile', 'China', 'Colombia',
    'Croatia', 'Cuba', 'Czech Republic', 'Denmark', 'Egypt', 'Ethiopia',
    'Finland', 'France', 'Germany', 'Greece', 'Hungary', 'Iceland', 'India',
    'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Japan',
    'Jordan', 'Kenya', 'South Korea', 'Mexico', 'Morocco', 'Netherlands',
    'New Zealand', 'Nigeria', 'Norway', 'Pakistan', 'Peru', 'Philippines',
    'Poland', 'Portugal', 'Romania', 'Russia', 'Saudi Arabia', 'Singapore',
    'South Africa', 'Spain', 'Sweden', 'Switzerland', 'Thailand', 'Turkey',
    'Ukraine', 'United Kingdom', 'United States', 'Vietnam'
];

// Platform settings
const PLATFORM_SIZE = 5;
const PLATFORM_SEGMENTS = 25;
const DIG_RADIUS = 0.5;
const DIG_DEPTH = 0.2;
const MAX_DIG_DEPTH = 1.5;

// ============================================
// GAME STATE
// ============================================

let scene, camera, renderer, controls;
let digPlatform, digHeights;
let currentCountry = null;
let artifactsFound = 0;
let totalArtifacts = 5;
let score = 0;
let raycaster = new THREE.Raycaster();
let mouse = new THREE.Vector2();
let artifacts = [];
let lobbyObjects = [];

// Shovel
let shovel = null;
let isShovelAnimating = false;

// Debug
let wallhackMarkers = [];
let wallhackEnabled = false;
let digTargetPoint = null;

// ============================================
// THREE.JS SETUP
// ============================================

async function init() {
    const canvas = document.getElementById('canvas');

    // Scene
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x3a3a3a);

    // Camera
    camera = new THREE.PerspectiveCamera(
        50,
        window.innerWidth / window.innerHeight,
        0.1,
        1000
    );
    camera.position.set(0, 6, 8);
    camera.lookAt(0, 1, 0);

    // Renderer
    renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.0;

    // Controls - RIGHT MOUSE for orbit
    controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.maxPolarAngle = Math.PI / 2.1;
    controls.minPolarAngle = Math.PI / 6;
    controls.minDistance = 3;
    controls.maxDistance = 15;
    controls.target.set(0, 1, 0);
    controls.mouseButtons = {
        LEFT: null, // Disable left mouse for orbit
        MIDDLE: THREE.MOUSE.DOLLY,
        RIGHT: THREE.MOUSE.ROTATE
    };

    // Create lobby environment
    createArchaeologyRoom();

    // Lighting
    setupLighting();

    // Load shovel
    await loadShovel();

    // Event listeners
    window.addEventListener('resize', onWindowResize);
    canvas.addEventListener('click', onCanvasClick);
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());

    // UI Events
    setupUI();

    // Preload models
    document.getElementById('loading').textContent = 'Loading 3D models...';
    await modelLoader.preloadAll();

    // Start game
    await startNewRound();

    // Hide loading
    document.getElementById('loading').style.display = 'none';

    // Animation loop
    animate();
}

async function loadShovel() {
    try {
        const loader = new GLTFLoader();
        const gltf = await loader.loadAsync('./public/models/low_poly_wooden_shovel.glb');
        const shovelModel = gltf.scene;

        // Normalize shovel size
        const box = new THREE.Box3().setFromObject(shovelModel);
        const size = new THREE.Vector3();
        box.getSize(size);
        const maxDim = Math.max(size.x, size.y, size.z);
        const scale = 1.5 / maxDim;
        shovelModel.scale.setScalar(scale);

        // Center the model
        box.setFromObject(shovelModel);
        const center = new THREE.Vector3();
        box.getCenter(center);
        shovelModel.position.sub(center);

        // Create a pivot group to correct the model's orientation
        // Rotate the model inside so blade points in -Y direction when wrapper has no rotation
        const pivotGroup = new THREE.Group();
        shovelModel.rotation.set(Math.PI, 0, 0); // Flip so blade is down
        pivotGroup.add(shovelModel);
        
        // Main wrapper for animation control
        shovel = new THREE.Group();
        shovel.add(pivotGroup);

        // Enable shadows
        shovel.traverse(child => {
            if (child.isMesh) {
                child.castShadow = true;
                child.receiveShadow = true;
            }
        });

        // Initial position (off to the side, resting)
        shovel.position.set(4, 1.0, 4);
        shovel.rotation.set(0.3, -Math.PI / 4, 0.2);
        scene.add(shovel);

        console.log('Shovel loaded successfully');
    } catch (error) {
        console.warn('Could not load shovel model:', error);
        // Create fallback shovel
        shovel = createFallbackShovel();
        scene.add(shovel);
    }
}

function createFallbackShovel() {
    const group = new THREE.Group();

    // Handle
    const handleGeo = new THREE.CylinderGeometry(0.03, 0.03, 1.2, 8);
    const handleMat = new THREE.MeshStandardMaterial({ color: 0x8b4513 });
    const handle = new THREE.Mesh(handleGeo, handleMat);
    handle.position.y = 0.6;
    group.add(handle);

    // Blade
    const bladeGeo = new THREE.BoxGeometry(0.3, 0.02, 0.35);
    const bladeMat = new THREE.MeshStandardMaterial({ color: 0x555555, metalness: 0.7 });
    const blade = new THREE.Mesh(bladeGeo, bladeMat);
    blade.position.y = -0.02;
    group.add(blade);

    group.castShadow = true;
    return group;
}

function setupLighting() {
    // Ambient - brighter for a well-lit museum feel
    const ambient = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambient);

    // Hemisphere light for natural fill
    const hemiLight = new THREE.HemisphereLight(0xfff8e8, 0x8b7355, 0.5);
    hemiLight.position.set(0, 10, 0);
    scene.add(hemiLight);

    // Main ceiling lights - brighter
    const ceilingLight1 = new THREE.SpotLight(0xfff5e6, 5);
    ceilingLight1.position.set(-3, 6, -3);
    ceilingLight1.angle = Math.PI / 2.5;
    ceilingLight1.penumbra = 0.6;
    ceilingLight1.decay = 1;
    ceilingLight1.castShadow = true;
    ceilingLight1.shadow.mapSize.width = 1024;
    ceilingLight1.shadow.mapSize.height = 1024;
    scene.add(ceilingLight1);

    const ceilingLight2 = new THREE.SpotLight(0xfff5e6, 5);
    ceilingLight2.position.set(3, 6, -3);
    ceilingLight2.angle = Math.PI / 2.5;
    ceilingLight2.penumbra = 0.6;
    ceilingLight2.decay = 1;
    ceilingLight2.castShadow = true;
    scene.add(ceilingLight2);

    // Additional ceiling lights for back of room
    const ceilingLight3 = new THREE.SpotLight(0xfff5e6, 4);
    ceilingLight3.position.set(-3, 6, 3);
    ceilingLight3.angle = Math.PI / 2.5;
    ceilingLight3.penumbra = 0.6;
    ceilingLight3.decay = 1;
    scene.add(ceilingLight3);

    const ceilingLight4 = new THREE.SpotLight(0xfff5e6, 4);
    ceilingLight4.position.set(3, 6, 3);
    ceilingLight4.angle = Math.PI / 2.5;
    ceilingLight4.penumbra = 0.6;
    ceilingLight4.decay = 1;
    scene.add(ceilingLight4);

    // Spotlight on dig platform - nice and bright
    const digLight = new THREE.SpotLight(0xffffff, 6);
    digLight.position.set(0, 5, 0);
    digLight.angle = Math.PI / 3;
    digLight.penumbra = 0.4;
    digLight.decay = 0.8;
    digLight.castShadow = true;
    digLight.shadow.mapSize.width = 2048;
    digLight.shadow.mapSize.height = 2048;
    digLight.target.position.set(0, 0, 0);
    scene.add(digLight);
    scene.add(digLight.target);

    // Display case accent lights - warmer and brighter
    const accentColor = 0xffd700;
    const accent1 = new THREE.PointLight(accentColor, 1.5, 8);
    accent1.position.set(-6, 2, -4);
    scene.add(accent1);

    const accent2 = new THREE.PointLight(accentColor, 1.5, 8);
    accent2.position.set(6, 2, -4);
    scene.add(accent2);

    // Wall wash lights
    const wallLight1 = new THREE.PointLight(0xfff0e0, 1, 10);
    wallLight1.position.set(-8, 3, 0);
    scene.add(wallLight1);

    const wallLight2 = new THREE.PointLight(0xfff0e0, 1, 10);
    wallLight2.position.set(8, 3, 0);
    scene.add(wallLight2);
}

// ============================================
// ARCHAEOLOGY ROOM
// ============================================

function createArchaeologyRoom() {
    // Floor - wooden parquet
    createFloor();

    // Walls
    createWalls();

    // Ceiling
    createCeiling();

    // Dig platform with barrier
    createPlatformArea();

    // Display cases
    createDisplayCases();

    // Wall decorations
    createWallDecorations();

    // Furniture
    createFurniture();
}

function createFloor() {
    const floorGeo = new THREE.PlaneGeometry(20, 20);
    const floorMat = new THREE.MeshStandardMaterial({
        color: 0x3d2817,
        roughness: 0.8,
        metalness: 0.1
    });
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.y = -0.5;
    floor.receiveShadow = true;
    scene.add(floor);
    lobbyObjects.push(floor);

    // Floor pattern (planks)
    for (let i = -9; i <= 9; i += 1) {
        const lineGeo = new THREE.BoxGeometry(20, 0.01, 0.02);
        const lineMat = new THREE.MeshStandardMaterial({ color: 0x2a1a0a });
        const line = new THREE.Mesh(lineGeo, lineMat);
        line.position.set(0, -0.49, i);
        scene.add(line);
        lobbyObjects.push(line);
    }
}

function createWalls() {
    const wallMat = new THREE.MeshStandardMaterial({
        color: 0x5a5a5a,
        roughness: 0.85
    });

    // Back wall
    const backWallGeo = new THREE.PlaneGeometry(20, 7);
    const backWall = new THREE.Mesh(backWallGeo, wallMat);
    backWall.position.set(0, 3, -10);
    backWall.receiveShadow = true;
    scene.add(backWall);
    lobbyObjects.push(backWall);

    // Side walls
    const sideWallGeo = new THREE.PlaneGeometry(20, 7);

    const leftWall = new THREE.Mesh(sideWallGeo, wallMat);
    leftWall.position.set(-10, 3, 0);
    leftWall.rotation.y = Math.PI / 2;
    scene.add(leftWall);
    lobbyObjects.push(leftWall);

    const rightWall = new THREE.Mesh(sideWallGeo, wallMat);
    rightWall.position.set(10, 3, 0);
    rightWall.rotation.y = -Math.PI / 2;
    scene.add(rightWall);
    lobbyObjects.push(rightWall);

    // Wainscoting (lower wall panels)
    const wainscotMat = new THREE.MeshStandardMaterial({ color: 0x3d2817 });

    const wainscotBack = new THREE.Mesh(
        new THREE.BoxGeometry(20, 1.5, 0.1),
        wainscotMat
    );
    wainscotBack.position.set(0, 0.25, -9.9);
    scene.add(wainscotBack);
    lobbyObjects.push(wainscotBack);
}

function createCeiling() {
    const ceilingGeo = new THREE.PlaneGeometry(20, 20);
    const ceilingMat = new THREE.MeshStandardMaterial({
        color: 0x4a4a4a,
        roughness: 0.9
    });
    const ceiling = new THREE.Mesh(ceilingGeo, ceilingMat);
    ceiling.rotation.x = Math.PI / 2;
    ceiling.position.y = 6.5;
    scene.add(ceiling);
    lobbyObjects.push(ceiling);

    // Ceiling beams - warmer wood tone
    const beamMat = new THREE.MeshStandardMaterial({ color: 0x5c4030 });
    for (let i = -6; i <= 6; i += 4) {
        const beam = new THREE.Mesh(
            new THREE.BoxGeometry(20, 0.3, 0.4),
            beamMat
        );
        beam.position.set(0, 6.3, i);
        scene.add(beam);
        lobbyObjects.push(beam);
    }
}

function createPlatformArea() {
    const frameSize = PLATFORM_SIZE + 0.6;

    // Stone platform base
    const baseGeo = new THREE.BoxGeometry(frameSize + 0.4, 0.3, frameSize + 0.4);
    const baseMat = new THREE.MeshStandardMaterial({
        color: 0x4a4a4a,
        roughness: 0.9
    });
    const base = new THREE.Mesh(baseGeo, baseMat);
    base.position.y = -0.35;
    base.receiveShadow = true;
    base.castShadow = true;
    scene.add(base);
    lobbyObjects.push(base);

    // Wooden frame around dig area
    const frameMat = new THREE.MeshStandardMaterial({
        color: 0x5c4030,
        roughness: 0.7
    });
    const frameHeight = 0.25;

    const sides = [
        { pos: [0, 0, frameSize/2], size: [frameSize + 0.3, frameHeight, 0.15] },
        { pos: [0, 0, -frameSize/2], size: [frameSize + 0.3, frameHeight, 0.15] },
        { pos: [frameSize/2, 0, 0], size: [0.15, frameHeight, frameSize] },
        { pos: [-frameSize/2, 0, 0], size: [0.15, frameHeight, frameSize] }
    ];

    sides.forEach(side => {
        const geo = new THREE.BoxGeometry(...side.size);
        const mesh = new THREE.Mesh(geo, frameMat);
        mesh.position.set(...side.pos);
        mesh.position.y = -0.07;
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        scene.add(mesh);
        lobbyObjects.push(mesh);
    });

    // Rope barriers
    createRopeBarrier();

    // Info plaque
    const plaqueGeo = new THREE.BoxGeometry(1.2, 0.6, 0.05);
    const plaqueMat = new THREE.MeshStandardMaterial({
        color: 0xc9a227,
        metalness: 0.8,
        roughness: 0.3
    });
    const plaque = new THREE.Mesh(plaqueGeo, plaqueMat);
    plaque.position.set(0, 0.3, frameSize/2 + 0.5);
    plaque.rotation.x = -Math.PI / 6;
    scene.add(plaque);
    lobbyObjects.push(plaque);
}

function createRopeBarrier() {
    const postMat = new THREE.MeshStandardMaterial({
        color: 0xc9a227,
        metalness: 0.7,
        roughness: 0.3
    });
    const ropeMat = new THREE.MeshStandardMaterial({
        color: 0x8b0000,
        roughness: 0.8
    });

    const postPositions = [
        [-4, 4], [4, 4], [-4, -4], [4, -4]
    ];

    postPositions.forEach(([x, z]) => {
        // Post
        const postGeo = new THREE.CylinderGeometry(0.05, 0.07, 1, 16);
        const post = new THREE.Mesh(postGeo, postMat);
        post.position.set(x, 0, z);
        post.castShadow = true;
        scene.add(post);
        lobbyObjects.push(post);

        // Top ball
        const ballGeo = new THREE.SphereGeometry(0.08, 16, 16);
        const ball = new THREE.Mesh(ballGeo, postMat);
        ball.position.set(x, 0.55, z);
        scene.add(ball);
        lobbyObjects.push(ball);
    });

    // Ropes
    const ropeConnections = [
        [[-4, 4], [4, 4]],
        [[-4, -4], [4, -4]],
        [[-4, 4], [-4, -4]],
        [[4, 4], [4, -4]]
    ];

    ropeConnections.forEach(([start, end]) => {
        const curve = new THREE.CatmullRomCurve3([
            new THREE.Vector3(start[0], 0.4, start[1]),
            new THREE.Vector3((start[0] + end[0]) / 2, 0.25, (start[1] + end[1]) / 2),
            new THREE.Vector3(end[0], 0.4, end[1])
        ]);

        const ropeGeo = new THREE.TubeGeometry(curve, 20, 0.02, 8, false);
        const rope = new THREE.Mesh(ropeGeo, ropeMat);
        scene.add(rope);
        lobbyObjects.push(rope);
    });
}

function createDisplayCases() {
    const caseMat = new THREE.MeshStandardMaterial({
        color: 0x2a1a0a,
        roughness: 0.5
    });
    const glassMat = new THREE.MeshStandardMaterial({
        color: 0xffffff,
        transparent: true,
        opacity: 0.15,
        roughness: 0.1,
        metalness: 0.1
    });

    // Left display case
    createDisplayCase(-6, -5, caseMat, glassMat);

    // Right display case
    createDisplayCase(6, -5, caseMat, glassMat);

    // Back wall display shelves
    createWallShelves();
}

function createDisplayCase(x, z, caseMat, glassMat) {
    const group = new THREE.Group();

    // Base
    const base = new THREE.Mesh(
        new THREE.BoxGeometry(2, 0.8, 1),
        caseMat
    );
    base.position.y = 0.4;
    base.castShadow = true;
    base.receiveShadow = true;
    group.add(base);

    // Glass top
    const glass = new THREE.Mesh(
        new THREE.BoxGeometry(1.8, 0.6, 0.9),
        glassMat
    );
    glass.position.y = 1.1;
    group.add(glass);

    // Display items (decorative)
    const itemGeo = new THREE.DodecahedronGeometry(0.15);
    const itemMat = new THREE.MeshStandardMaterial({
        color: 0xffd700,
        metalness: 0.8
    });
    const item = new THREE.Mesh(itemGeo, itemMat);
    item.position.y = 0.95;
    item.castShadow = true;
    group.add(item);

    group.position.set(x, -0.5, z);
    scene.add(group);
    lobbyObjects.push(group);
}

function createWallShelves() {
    const shelfMat = new THREE.MeshStandardMaterial({ color: 0x3d2817 });

    // Create shelves on back wall
    for (let i = 0; i < 3; i++) {
        const shelf = new THREE.Mesh(
            new THREE.BoxGeometry(2.5, 0.1, 0.4),
            shelfMat
        );
        shelf.position.set(-5 + i * 5, 2.5, -9.7);
        shelf.castShadow = true;
        shelf.receiveShadow = true;
        scene.add(shelf);
        lobbyObjects.push(shelf);

        // Items on shelf
        for (let j = 0; j < 3; j++) {
            const itemTypes = [
                () => new THREE.CylinderGeometry(0.08, 0.1, 0.25, 8),
                () => new THREE.BoxGeometry(0.15, 0.2, 0.1),
                () => new THREE.SphereGeometry(0.1, 8, 8)
            ];
            const itemGeo = itemTypes[j]();
            const itemMat = new THREE.MeshStandardMaterial({
                color: [0xcd853f, 0x8b7355, 0x696969][j]
            });
            const item = new THREE.Mesh(itemGeo, itemMat);
            item.position.set(-5.8 + i * 5 + j * 0.6, 2.7, -9.5);
            item.castShadow = true;
            scene.add(item);
            lobbyObjects.push(item);
        }
    }
}

function createWallDecorations() {
    // World map on back wall - frame first, then map in front
    const frameGeo = new THREE.BoxGeometry(4.2, 2.7, 0.1);
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x3d2817 });
    const frame = new THREE.Mesh(frameGeo, frameMat);
    frame.position.set(0, 3.5, -9.9);
    scene.add(frame);
    lobbyObjects.push(frame);

    // Map sits on top of frame
    const mapGeo = new THREE.PlaneGeometry(4, 2.5);
    const mapMat = new THREE.MeshStandardMaterial({
        color: 0xd4b896,
        roughness: 0.9
    });
    const map = new THREE.Mesh(mapGeo, mapMat);
    map.position.set(0, 3.5, -9.84);
    scene.add(map);
    lobbyObjects.push(map);

    // Side wall pictures
    const picPositions = [
        { pos: [-9.9, 3, -3], rot: Math.PI / 2 },
        { pos: [-9.9, 3, 3], rot: Math.PI / 2 },
        { pos: [9.9, 3, -3], rot: -Math.PI / 2 },
        { pos: [9.9, 3, 3], rot: -Math.PI / 2 }
    ];

    picPositions.forEach(({ pos, rot }) => {
        // Frame first
        const picFrame = new THREE.Mesh(
            new THREE.BoxGeometry(1.7, 1.4, 0.08),
            new THREE.MeshStandardMaterial({ color: 0xc9a227 })
        );
        picFrame.position.set(...pos);
        picFrame.rotation.y = rot;
        scene.add(picFrame);
        lobbyObjects.push(picFrame);

        // Picture on top of frame
        const picGeo = new THREE.PlaneGeometry(1.5, 1.2);
        const picMat = new THREE.MeshStandardMaterial({ color: 0x4a3020 });
        const pic = new THREE.Mesh(picGeo, picMat);
        const offset = rot > 0 ? 0.05 : -0.05;
        pic.position.set(pos[0] + offset, pos[1], pos[2]);
        pic.rotation.y = rot;
        scene.add(pic);
        lobbyObjects.push(pic);
    });
}

function createFurniture() {
    // Work desk on the side
    const deskMat = new THREE.MeshStandardMaterial({ color: 0x3d2817 });

    const deskTop = new THREE.Mesh(
        new THREE.BoxGeometry(2, 0.1, 1),
        deskMat
    );
    deskTop.position.set(-7, 0.3, 2);
    deskTop.castShadow = true;
    deskTop.receiveShadow = true;
    scene.add(deskTop);
    lobbyObjects.push(deskTop);

    // Desk legs
    const legGeo = new THREE.BoxGeometry(0.1, 0.8, 0.1);
    const legPositions = [[-7.9, 1.6], [-7.9, 2.4], [-6.1, 1.6], [-6.1, 2.4]];
    legPositions.forEach(([x, z]) => {
        const leg = new THREE.Mesh(legGeo, deskMat);
        leg.position.set(x, -0.1, z);
        scene.add(leg);
        lobbyObjects.push(leg);
    });

    // Items on desk
    const lampBase = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1, 0.12, 0.05, 16),
        new THREE.MeshStandardMaterial({ color: 0x333333 })
    );
    lampBase.position.set(-7.5, 0.38, 2.2);
    scene.add(lampBase);
    lobbyObjects.push(lampBase);

    const lampArm = new THREE.Mesh(
        new THREE.CylinderGeometry(0.02, 0.02, 0.5, 8),
        new THREE.MeshStandardMaterial({ color: 0x444444 })
    );
    lampArm.position.set(-7.5, 0.63, 2.2);
    scene.add(lampArm);
    lobbyObjects.push(lampArm);

    // Book stack
    const bookColors = [0x8b0000, 0x006400, 0x00008b];
    bookColors.forEach((color, i) => {
        const book = new THREE.Mesh(
            new THREE.BoxGeometry(0.25, 0.05, 0.18),
            new THREE.MeshStandardMaterial({ color })
        );
        book.position.set(-6.5, 0.38 + i * 0.05, 2.3);
        book.rotation.y = Math.random() * 0.2;
        scene.add(book);
        lobbyObjects.push(book);
    });

    // Chair
    const chairMat = new THREE.MeshStandardMaterial({ color: 0x2a1a0a });
    const chairSeat = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 0.05, 0.5),
        chairMat
    );
    chairSeat.position.set(-7, 0, 3);
    scene.add(chairSeat);
    lobbyObjects.push(chairSeat);

    const chairBack = new THREE.Mesh(
        new THREE.BoxGeometry(0.5, 0.6, 0.05),
        chairMat
    );
    chairBack.position.set(-7, 0.3, 3.22);
    scene.add(chairBack);
    lobbyObjects.push(chairBack);
}

// ============================================
// DIG PLATFORM
// ============================================

// Store terrain sides for cleanup
let terrainSides = [];
let terrainBase = null;

// Simple seeded random for consistent terrain
function seededRandom(seed) {
    const x = Math.sin(seed) * 10000;
    return x - Math.floor(x);
}

// Simple noise function (like Perlin but simpler)
function noise2D(x, y, seed) {
    const n = Math.sin(x * 12.9898 + y * 78.233 + seed) * 43758.5453;
    return n - Math.floor(n);
}

// Smooth noise with interpolation
function smoothNoise(x, y, seed) {
    const x0 = Math.floor(x);
    const y0 = Math.floor(y);
    const x1 = x0 + 1;
    const y1 = y0 + 1;
    
    const sx = x - x0;
    const sy = y - y0;
    
    // Smooth interpolation
    const smoothX = sx * sx * (3 - 2 * sx);
    const smoothY = sy * sy * (3 - 2 * sy);
    
    const n00 = noise2D(x0, y0, seed);
    const n10 = noise2D(x1, y0, seed);
    const n01 = noise2D(x0, y1, seed);
    const n11 = noise2D(x1, y1, seed);
    
    const nx0 = n00 * (1 - smoothX) + n10 * smoothX;
    const nx1 = n01 * (1 - smoothX) + n11 * smoothX;
    
    return nx0 * (1 - smoothY) + nx1 * smoothY;
}

// Multi-octave noise for more natural terrain
function terrainNoise(x, y, seed) {
    let value = 0;
    let amplitude = 1;
    let frequency = 1;
    let maxValue = 0;
    
    // 3 octaves of noise
    for (let i = 0; i < 3; i++) {
        value += smoothNoise(x * frequency, y * frequency, seed + i * 100) * amplitude;
        maxValue += amplitude;
        amplitude *= 0.5;
        frequency *= 2;
    }
    
    return value / maxValue;
}

function createDigPlatform(country) {
    // Clean up old platform
    if (digPlatform) {
        scene.remove(digPlatform);
        digPlatform.geometry.dispose();
        digPlatform.material.dispose();
    }
    
    // Clean up old sides and base
    terrainSides.forEach(side => {
        scene.remove(side);
        if (side.geometry) side.geometry.dispose();
        if (side.material) side.material.dispose();
    });
    terrainSides = [];
    
    if (terrainBase) {
        scene.remove(terrainBase);
        if (terrainBase.geometry) terrainBase.geometry.dispose();
        if (terrainBase.material) terrainBase.material.dispose();
        terrainBase = null;
    }

    // Generate a random seed for this terrain
    const terrainSeed = Math.random() * 10000;
    
    // Base terrain height and variation
    const TERRAIN_HEIGHT = 1.0;
    const HEIGHT_VARIATION = 0.6;
    
    digHeights = new Float32Array((PLATFORM_SEGMENTS + 1) * (PLATFORM_SEGMENTS + 1));
    
    // Create the top diggable surface with noise-based height
    const geometry = new THREE.PlaneGeometry(
        PLATFORM_SIZE,
        PLATFORM_SIZE,
        PLATFORM_SEGMENTS,
        PLATFORM_SEGMENTS
    );

    // Generate random mountain/hill positions (1-3 mountains per terrain)
    const numMountains = 1 + Math.floor(seededRandom(terrainSeed) * 3);
    const mountains = [];
    for (let m = 0; m < numMountains; m++) {
        mountains.push({
            x: (seededRandom(terrainSeed + m * 100) - 0.5) * (PLATFORM_SIZE - 1.5),
            y: (seededRandom(terrainSeed + m * 100 + 50) - 0.5) * (PLATFORM_SIZE - 1.5),
            height: 0.4 + seededRandom(terrainSeed + m * 100 + 25) * 0.5, // 0.4 to 0.9 height
            radius: 0.8 + seededRandom(terrainSeed + m * 100 + 75) * 1.0  // 0.8 to 1.8 radius
        });
    }

    const positions = geometry.attributes.position;
    const heightMap = []; // Store heights for edge matching
    
    for (let i = 0; i < positions.count; i++) {
        const x = positions.getX(i);
        const y = positions.getY(i);
        
        // Base noise layers
        const fineNoise = terrainNoise(x * 0.6, y * 0.6, terrainSeed) * 0.15;
        const mediumNoise = terrainNoise(x * 0.3, y * 0.3, terrainSeed + 100) * 0.25;
        const largeNoise = terrainNoise(x * 0.15, y * 0.15, terrainSeed + 500) * 0.3;
        
        // Combine base noise
        let height = (fineNoise + mediumNoise + largeNoise - 0.35) * HEIGHT_VARIATION * 2;
        
        // Add mountain peaks!
        for (const mountain of mountains) {
            const dx = x - mountain.x;
            const dy = y - mountain.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            
            if (dist < mountain.radius) {
                // Smooth mountain shape (like a bell curve)
                const t = dist / mountain.radius;
                // Use cosine for smooth mountain shape
                const mountainHeight = mountain.height * Math.cos(t * Math.PI / 2) * Math.cos(t * Math.PI / 2);
                height += mountainHeight;
            }
        }
        
        // Add some random small valleys too
        const valleyNoise = terrainNoise(x * 0.25, y * 0.25, terrainSeed + 777);
        if (valleyNoise < 0.2) {
            height -= 0.15 * (0.2 - valleyNoise) * 5;
        }
        
        positions.setZ(i, height);
        digHeights[i] = height;
        
        // Store for edge matching
        const col = i % (PLATFORM_SEGMENTS + 1);
        const row = Math.floor(i / (PLATFORM_SEGMENTS + 1));
        if (!heightMap[row]) heightMap[row] = [];
        heightMap[row][col] = height;
    }
    geometry.computeVertexNormals();

    const terrainColor = new THREE.Color(country.terrain.color);
    const darkerColor = terrainColor.clone().multiplyScalar(0.7);
    const darkestColor = terrainColor.clone().multiplyScalar(0.4);

    const material = new THREE.MeshStandardMaterial({
        color: country.terrain.color,
        roughness: country.terrain.roughness,
        metalness: 0.0,
        flatShading: true
    });

    digPlatform = new THREE.Mesh(geometry, material);
    digPlatform.rotation.x = -Math.PI / 2;
    digPlatform.position.y = TERRAIN_HEIGHT;
    digPlatform.receiveShadow = true;
    digPlatform.castShadow = true;
    digPlatform.name = 'digPlatform';
    scene.add(digPlatform);

    // Create SOLID sides using BufferGeometry for proper closed mesh
    const sideMaterial = new THREE.MeshStandardMaterial({
        color: darkerColor,
        roughness: country.terrain.roughness + 0.1,
        metalness: 0.0,
        flatShading: true,
        side: THREE.DoubleSide
    });

    // Create each side as a solid shape that matches the top edge heights
    // Front side (z = +PLATFORM_SIZE/2)
    createTerrainSide('front', heightMap, TERRAIN_HEIGHT, sideMaterial.clone(), terrainSides);
    
    // Back side (z = -PLATFORM_SIZE/2)
    createTerrainSide('back', heightMap, TERRAIN_HEIGHT, sideMaterial.clone(), terrainSides);
    
    // Left side (x = -PLATFORM_SIZE/2)
    createTerrainSide('left', heightMap, TERRAIN_HEIGHT, sideMaterial.clone(), terrainSides);
    
    // Right side (x = +PLATFORM_SIZE/2)
    createTerrainSide('right', heightMap, TERRAIN_HEIGHT, sideMaterial.clone(), terrainSides);

    // Bottom/base - slightly larger to ensure no gaps
    const baseMaterial = new THREE.MeshStandardMaterial({
        color: darkestColor,
        roughness: 1,
        metalness: 0
    });
    const baseGeo = new THREE.PlaneGeometry(PLATFORM_SIZE + 0.1, PLATFORM_SIZE + 0.1);
    terrainBase = new THREE.Mesh(baseGeo, baseMaterial);
    terrainBase.rotation.x = -Math.PI / 2;
    terrainBase.position.y = 0.001;
    terrainBase.receiveShadow = true;
    scene.add(terrainBase);

    addTerrainDetails(country, TERRAIN_HEIGHT);
}

function createTerrainSide(side, heightMap, baseHeight, material, sidesArray) {
    const segments = PLATFORM_SEGMENTS;
    const halfSize = PLATFORM_SIZE / 2;
    const segmentSize = PLATFORM_SIZE / segments;
    
    // Get the edge heights from the heightMap
    let edgeHeights = [];
    
    if (side === 'front') {
        // Bottom row of heightMap (z = +halfSize in world)
        edgeHeights = [...heightMap[segments]];
    } else if (side === 'back') {
        // Top row of heightMap (z = -halfSize in world)  
        edgeHeights = [...heightMap[0]].reverse();
    } else if (side === 'left') {
        // First column (reversed for correct winding)
        for (let row = segments; row >= 0; row--) {
            edgeHeights.push(heightMap[row][0]);
        }
    } else if (side === 'right') {
        // Last column
        for (let row = 0; row <= segments; row++) {
            edgeHeights.push(heightMap[row][segments]);
        }
    }
    
    // Create vertices for the side
    const vertices = [];
    const indices = [];
    
    for (let i = 0; i <= segments; i++) {
        const edgeHeight = edgeHeights[i] !== undefined ? edgeHeights[i] : 0;
        
        let x, z;
        if (side === 'front') {
            x = -halfSize + i * segmentSize;
            z = halfSize;
        } else if (side === 'back') {
            x = halfSize - i * segmentSize;
            z = -halfSize;
        } else if (side === 'left') {
            x = -halfSize;
            z = halfSize - i * segmentSize;
        } else if (side === 'right') {
            x = halfSize;
            z = -halfSize + i * segmentSize;
        }
        
        // Top vertex (at terrain surface)
        vertices.push(x, baseHeight + edgeHeight, z);
        // Bottom vertex (at ground level)
        vertices.push(x, 0, z);
    }
    
    // Create triangles
    for (let i = 0; i < segments; i++) {
        const topLeft = i * 2;
        const bottomLeft = i * 2 + 1;
        const topRight = (i + 1) * 2;
        const bottomRight = (i + 1) * 2 + 1;
        
        // Two triangles per quad
        indices.push(topLeft, bottomLeft, topRight);
        indices.push(bottomLeft, bottomRight, topRight);
    }
    
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    
    const mesh = new THREE.Mesh(geometry, material);
    mesh.receiveShadow = true;
    mesh.castShadow = true;
    scene.add(mesh);
    sidesArray.push(mesh);
}

function addTerrainDetails(country, terrainHeight) {
    const particleCount = 50;
    const colors = {
        sand: [0xc2a060, 0xa08040, 0xd4b874],
        dirt: [0x5c4030, 0x4a3020, 0x6b5040],
        soil: [0x3d2817, 0x2d1807, 0x4d3827]
    };
    const typeColors = colors[country.terrain.type] || colors.dirt;

    // Helper to get terrain height at a position
    const getTerrainHeightAt = (x, z) => {
        if (!digPlatform) return terrainHeight;
        const positions = digPlatform.geometry.attributes.position;
        const localX = x;
        const localY = -z;
        
        let minDist = Infinity;
        let height = 0;
        
        for (let i = 0; i < positions.count; i++) {
            const vx = positions.getX(i);
            const vy = positions.getY(i);
            const dist = Math.sqrt((vx - localX) ** 2 + (vy - localY) ** 2);
            if (dist < minDist) {
                minDist = dist;
                height = positions.getZ(i);
            }
        }
        return terrainHeight + height;
    };

    // Scatter rocks/pebbles on top surface
    for (let i = 0; i < particleCount; i++) {
        const size = 0.02 + Math.random() * 0.05;
        const geo = new THREE.DodecahedronGeometry(size, 0);
        const mat = new THREE.MeshStandardMaterial({
            color: typeColors[Math.floor(Math.random() * typeColors.length)],
            roughness: 1
        });
        const particle = new THREE.Mesh(geo, mat);
        const px = (Math.random() - 0.5) * (PLATFORM_SIZE - 0.5);
        const pz = (Math.random() - 0.5) * (PLATFORM_SIZE - 0.5);
        const surfaceHeight = getTerrainHeightAt(px, pz);
        particle.position.set(px, surfaceHeight + 0.02 + Math.random() * 0.02, pz);
        particle.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
        particle.castShadow = true;
        particle.userData.isParticle = true;
        scene.add(particle);
    }
    
    // Add some larger rocks/clumps
    for (let i = 0; i < 8; i++) {
        const size = 0.06 + Math.random() * 0.08;
        const geo = new THREE.DodecahedronGeometry(size, 1);
        const mat = new THREE.MeshStandardMaterial({
            color: typeColors[Math.floor(Math.random() * typeColors.length)],
            roughness: 0.9
        });
        const rock = new THREE.Mesh(geo, mat);
        const rx = (Math.random() - 0.5) * (PLATFORM_SIZE - 0.8);
        const rz = (Math.random() - 0.5) * (PLATFORM_SIZE - 0.8);
        const surfaceHeight = getTerrainHeightAt(rx, rz);
        rock.position.set(rx, surfaceHeight + size * 0.3, rz);
        rock.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
        rock.scale.y = 0.5 + Math.random() * 0.3;
        rock.castShadow = true;
        rock.receiveShadow = true;
        rock.userData.isParticle = true;
        scene.add(rock);
    }
}

function darkenColor(color, amount) {
    const c = new THREE.Color(color);
    c.multiplyScalar(1 - amount);
    return c;
}

// ============================================
// SHOVEL DIGGING ANIMATION
// ============================================

function onCanvasClick(event) {
    if (isShovelAnimating) return;

    const rect = renderer.domElement.getBoundingClientRect();
    mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObject(digPlatform);

    if (intersects.length > 0) {
        const point = intersects[0].point;
        animateShovelDig(point);
    }
}

function animateShovelDig(targetPoint) {
    if (!shovel || isShovelAnimating) return;
    isShovelAnimating = true;
    digTargetPoint = targetPoint.clone();

    const startPos = shovel.position.clone();
    const startRot = new THREE.Euler().copy(shovel.rotation);

    // Get the terrain height at the dig point
    const terrainHeight = targetPoint.y;

    // Animation phases - realistic shovel motion
    const phase1Duration = 200;  // Position above, blade vertical
    const phase2Duration = 150;  // Push blade straight down into ground
    const phase3Duration = 100;  // Push deeper (like stepping on shovel)
    const phase4Duration = 250;  // Lever handle back to scoop
    const phase5Duration = 200;  // Lift dirt out of hole
    const phase6Duration = 300;  // Swing and throw dirt
    const phase7Duration = 250;  // Return to rest

    const startTime = Date.now();

    // Key positions for realistic dig motion
    const abovePos = new THREE.Vector3(targetPoint.x, terrainHeight + 0.6, targetPoint.z + 0.3);
    const insertPos = new THREE.Vector3(targetPoint.x, terrainHeight + 0.1, targetPoint.z + 0.15);
    const deepPos = new THREE.Vector3(targetPoint.x, terrainHeight - 0.1, targetPoint.z + 0.1);
    const leverPos = new THREE.Vector3(targetPoint.x, terrainHeight + 0.2, targetPoint.z + 0.5);
    const liftPos = new THREE.Vector3(targetPoint.x, terrainHeight + 0.8, targetPoint.z + 0.6);
    const throwPos = new THREE.Vector3(targetPoint.x + 1.0, terrainHeight + 0.5, targetPoint.z + 0.8);

    function animatePhase() {
        const elapsed = Date.now() - startTime;
        let progress;
        let phaseEnd = 0;

        // Phase 1: Position above dig point, blade angled but more upright
        phaseEnd = phase1Duration;
        if (elapsed < phaseEnd) {
            progress = elapsed / phase1Duration;
            const eased = easeOutCubic(progress);
            shovel.position.lerpVectors(startPos, abovePos, eased);
            // Blade more upright, slight forward tilt
            shovel.rotation.x = lerp(startRot.x, 0.5, eased);
            shovel.rotation.y = lerp(startRot.y, 0, eased);
            shovel.rotation.z = lerp(startRot.z, 0, eased);
            requestAnimationFrame(animatePhase);
            return;
        }

        // Phase 2: Push blade down into ground
        phaseEnd += phase2Duration;
        if (elapsed < phaseEnd) {
            progress = (elapsed - phase1Duration) / phase2Duration;
            const eased = easeInCubic(progress);
            shovel.position.lerpVectors(abovePos, insertPos, eased);
            // Tilt forward a bit as it goes in
            shovel.rotation.x = lerp(0.5, 0.3, eased);
            requestAnimationFrame(animatePhase);
            return;
        }

        // Phase 3: Push deeper (like stepping on it)
        phaseEnd += phase3Duration;
        if (elapsed < phaseEnd) {
            progress = (elapsed - phase1Duration - phase2Duration) / phase3Duration;
            const eased = easeInCubic(progress);
            shovel.position.lerpVectors(insertPos, deepPos, eased);
            // Slight more forward as it goes deeper
            shovel.rotation.x = lerp(0.3, 0.15, eased);
            
            // Trigger dig here
            if (progress < 0.2) {
                digAt(targetPoint.x, targetPoint.z);
            }
            requestAnimationFrame(animatePhase);
            return;
        }

        // Phase 4: Lever handle back to scoop dirt onto blade
        phaseEnd += phase4Duration;
        if (elapsed < phaseEnd) {
            progress = (elapsed - phase1Duration - phase2Duration - phase3Duration) / phase4Duration;
            const eased = easeOutCubic(progress);
            shovel.position.lerpVectors(deepPos, leverPos, eased);
            // Pull handle back - blade tips up to scoop
            shovel.rotation.x = lerp(0.15, 1.4, eased);
            requestAnimationFrame(animatePhase);
            return;
        }

        // Phase 5: Lift dirt out of hole
        phaseEnd += phase5Duration;
        if (elapsed < phaseEnd) {
            progress = (elapsed - phase1Duration - phase2Duration - phase3Duration - phase4Duration) / phase5Duration;
            const eased = easeOutCubic(progress);
            shovel.position.lerpVectors(leverPos, liftPos, eased);
            // Keep blade tipped back to hold dirt
            shovel.rotation.x = lerp(1.4, 1.2, eased);
            requestAnimationFrame(animatePhase);
            return;
        }

        // Phase 6: Swing to side and throw dirt
        phaseEnd += phase6Duration;
        if (elapsed < phaseEnd) {
            progress = (elapsed - phase1Duration - phase2Duration - phase3Duration - phase4Duration - phase5Duration) / phase6Duration;
            const eased = easeOutCubic(progress);
            shovel.position.lerpVectors(liftPos, throwPos, eased);
            // Twist and flip to dump dirt
            shovel.rotation.x = lerp(1.2, 0.6, eased);
            shovel.rotation.y = lerp(0, -1.2, eased);
            shovel.rotation.z = lerp(0, 0.5, eased);

            // Create dirt particles when dumping
            if (progress > 0.3 && progress < 0.45) {
                createThrownDirt(shovel.position.clone());
            }
            requestAnimationFrame(animatePhase);
            return;
        }

        // Phase 7: Return to rest
        phaseEnd += phase7Duration;
        if (elapsed < phaseEnd) {
            progress = (elapsed - phase1Duration - phase2Duration - phase3Duration - phase4Duration - phase5Duration - phase6Duration) / phase7Duration;
            const eased = easeOutCubic(progress);
            shovel.position.lerpVectors(throwPos, startPos, eased);
            shovel.rotation.x = lerp(0.6, startRot.x, eased);
            shovel.rotation.y = lerp(-1.2, startRot.y, eased);
            shovel.rotation.z = lerp(0.5, startRot.z, eased);
            requestAnimationFrame(animatePhase);
            return;
        }

        // Animation complete
        shovel.position.copy(startPos);
        shovel.rotation.copy(startRot);
        isShovelAnimating = false;
    }

    animatePhase();
}

function lerp(a, b, t) {
    return a + (b - a) * t;
}

function easeOutCubic(t) {
    return 1 - Math.pow(1 - t, 3);
}

function easeInCubic(t) {
    return t * t * t;
}

function createThrownDirt(position) {
    const particleCount = 15;

    for (let i = 0; i < particleCount; i++) {
        const size = 0.03 + Math.random() * 0.05;
        const geo = new THREE.SphereGeometry(size, 4, 4);
        const mat = new THREE.MeshBasicMaterial({
            color: currentCountry.terrain.color,
            transparent: true,
            opacity: 0.9
        });
        const particle = new THREE.Mesh(geo, mat);
        particle.position.copy(position);
        particle.position.x += (Math.random() - 0.5) * 0.3;
        particle.position.z += (Math.random() - 0.5) * 0.3;

        scene.add(particle);

        const velocityX = 0.02 + Math.random() * 0.03;
        const velocityY = 0.03 + Math.random() * 0.02;
        const velocityZ = (Math.random() - 0.5) * 0.02;
        const gravity = 0.003;
        const startTime = Date.now();

        function animateParticle() {
            const elapsed = Date.now() - startTime;
            const progress = elapsed / 800;

            if (progress < 1 && particle.position.y > -0.4) {
                particle.position.x += velocityX;
                particle.position.y += velocityY - gravity * elapsed * 0.01;
                particle.position.z += velocityZ;
                particle.material.opacity = 0.9 * (1 - progress);
                requestAnimationFrame(animateParticle);
            } else {
                scene.remove(particle);
                particle.geometry.dispose();
                particle.material.dispose();
            }
        }
        animateParticle();
    }
}

// ============================================
// TERRAIN DIGGING
// ============================================

function digAt(worldX, worldZ) {
    if (!digPlatform) return;

    const geometry = digPlatform.geometry;
    const positions = geometry.attributes.position;

    // Convert world coordinates to local platform coordinates
    // The platform is rotated -90 degrees on X axis, so:
    // - local X = world X
    // - local Y = -world Z (due to rotation)
    const localX = worldX;
    const localY = -worldZ;

    let dug = false;

    for (let i = 0; i < positions.count; i++) {
        const vx = positions.getX(i);
        const vy = positions.getY(i);

        const dx = vx - localX;
        const dy = vy - localY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < DIG_RADIUS) {
            const strength = 1 - (dist / DIG_RADIUS);
            const digAmount = DIG_DEPTH * strength * strength;

            const currentZ = positions.getZ(i);
            const newZ = Math.max(currentZ - digAmount, -MAX_DIG_DEPTH);

            if (newZ !== currentZ) {
                positions.setZ(i, newZ);
                digHeights[i] = newZ;
                dug = true;
            }
        }
    }

    if (dug) {
        positions.needsUpdate = true;
        geometry.computeVertexNormals();
        checkArtifactReveal(worldX, worldZ);
    }
}

// ============================================
// ARTIFACT SYSTEM
// ============================================

function createDirtMound(position, country, revealDepth) {
    // No longer needed - terrain is now a thick pile
    return null;
}

async function placeArtifacts(country) {
    // Remove old artifacts
    artifacts.forEach(a => {
        scene.remove(a.mesh);
    });
    artifacts = [];
    
    const TERRAIN_HEIGHT = 1.0;

    const positions = [];
    const minDist = 1.2;
    
    // Use the number of artifacts defined for this country
    const numArtifacts = country.artifacts.length;
    totalArtifacts = numArtifacts;

    for (let i = 0; i < numArtifacts; i++) {
        let pos;
        let attempts = 0;

        do {
            pos = new THREE.Vector2(
                (Math.random() - 0.5) * (PLATFORM_SIZE - 1.5),
                (Math.random() - 0.5) * (PLATFORM_SIZE - 1.5)
            );
            attempts++;
        } while (
            positions.some(p => p.distanceTo(pos) < minDist) &&
            attempts < 50
            );

        positions.push(pos);

        const artifactType = country.artifacts[i];
        const mesh = await createArtifact(artifactType);

        // Artifacts are buried INSIDE the terrain pile
        // revealDepth is how deep you need to dig to find it
        const revealDepth = 0.4 + Math.random() * 0.5;
        
        // Position artifact inside the terrain (below the surface)
        // Surface is at TERRAIN_HEIGHT, artifact is buried below that
        mesh.position.set(pos.x, TERRAIN_HEIGHT - revealDepth - 0.3, pos.y);
        mesh.visible = false;
        mesh.userData.revealed = false;
        mesh.userData.revealDepth = revealDepth;
        mesh.userData.baseY = mesh.position.y;
        scene.add(mesh);

        artifacts.push({
            mesh,
            position: pos,
            type: artifactType,
            revealed: false,
            revealDepth: revealDepth
        });
    }
}

function checkArtifactReveal(digX, digZ) {
    const TERRAIN_HEIGHT = 1.0;
    
    artifacts.forEach(artifact => {
        if (artifact.revealed) return;

        const dx = artifact.position.x - digX;
        const dz = artifact.position.y - digZ;
        const dist = Math.sqrt(dx * dx + dz * dz);

        if (dist < DIG_RADIUS * 2.5) {
            const depth = getDigDepthAt(artifact.position.x, artifact.position.y);
            const progress = Math.min(depth / artifact.revealDepth, 1);
            
            // Start showing artifact tip when you've dug deep enough
            if (progress > 0.4 && !artifact.mesh.visible) {
                artifact.mesh.visible = true;
            }
            
            // Gradually raise artifact as digging continues
            if (artifact.mesh.visible && !artifact.revealed) {
                // Artifact rises as you dig deeper
                const baseY = TERRAIN_HEIGHT - artifact.revealDepth - 0.3;
                const riseAmount = progress * 0.5;
                artifact.mesh.position.y = baseY + riseAmount;
            }

            if (depth >= artifact.revealDepth) {
                revealArtifact(artifact);
            }
        }
    });
}

function getDigDepthAt(x, z) {
    if (!digPlatform) return 0;

    const positions = digPlatform.geometry.attributes.position;
    let minDist = Infinity;
    let depth = 0;

    // Convert world coordinates to local platform coordinates
    const localX = x;
    const localY = -z;

    for (let i = 0; i < positions.count; i++) {
        const vx = positions.getX(i);
        const vy = positions.getY(i);
        const dist = Math.sqrt((vx - localX) ** 2 + (vy - localY) ** 2);

        if (dist < minDist) {
            minDist = dist;
            depth = -positions.getZ(i);
        }
    }

    return depth;
}

function revealArtifact(artifact) {
    const TERRAIN_HEIGHT = 1.0;
    
    artifact.revealed = true;
    artifact.mesh.visible = true;
    artifact.mesh.userData.revealed = true;

    // Update wallhack markers (remove this artifact's marker)
    if (wallhackEnabled) {
        updateWallhackMarkers();
    }

    const startY = artifact.mesh.position.y;
    const targetY = TERRAIN_HEIGHT + 0.4; // Pop up above the terrain surface
    const startTime = Date.now();
    const duration = 1000;

    function animateReveal() {
        const elapsed = Date.now() - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);

        artifact.mesh.position.y = startY + (targetY - startY) * eased;
        artifact.mesh.rotation.y += 0.05 * (1 - progress);

        if (progress < 1) {
            requestAnimationFrame(animateReveal);
        } else {
            artifactsFound++;
            updateUI();
            showRevealEffect(artifact.mesh.position);
        }
    }

    animateReveal();
}

function showRevealEffect(position) {
    const ringGeo = new THREE.RingGeometry(0.1, 0.5, 32);
    const ringMat = new THREE.MeshBasicMaterial({
        color: 0xffd700,
        transparent: true,
        opacity: 1,
        side: THREE.DoubleSide
    });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.position.copy(position);
    ring.position.y = 0.1;
    ring.rotation.x = -Math.PI / 2;
    scene.add(ring);

    const startTime = Date.now();

    function animateRing() {
        const elapsed = Date.now() - startTime;
        const progress = elapsed / 500;

        if (progress < 1) {
            ring.scale.setScalar(1 + progress * 2);
            ring.material.opacity = 1 - progress;
            requestAnimationFrame(animateRing);
        } else {
            scene.remove(ring);
            ring.geometry.dispose();
            ring.material.dispose();
        }
    }

    animateRing();
}

async function createArtifact(type) {
    const gltfModel = await modelLoader.loadModel(type);
    if (gltfModel) return gltfModel;
    return createProceduralArtifact(type);
}

function createProceduralArtifact(type) {
    const artifacts = {
        pyramid: () => new THREE.Mesh(new THREE.ConeGeometry(0.3, 0.5, 4), new THREE.MeshStandardMaterial({ color: 0xd4a574 })),
        sphinx: () => new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.2, 0.2), new THREE.MeshStandardMaterial({ color: 0xd4a574 })),
        ankh: () => new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.03, 8, 16), new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.8 })),
        scarab: () => new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 6), new THREE.MeshStandardMaterial({ color: 0x2e8b57 })),
        pharaoh_mask: () => new THREE.Mesh(new THREE.BoxGeometry(0.25, 0.35, 0.2), new THREE.MeshStandardMaterial({ color: 0xffd700, metalness: 0.9 })),
        column: () => new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.5, 12), new THREE.MeshStandardMaterial({ color: 0xf5f5dc })),
        amphora: () => { const m = new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 12), new THREE.MeshStandardMaterial({ color: 0xcd853f })); m.scale.y = 1.5; return m; },
        helmet: () => new THREE.Mesh(new THREE.SphereGeometry(0.2, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0xb8860b, metalness: 0.8 })),
        olive_branch: () => new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 0.4, 8), new THREE.MeshStandardMaterial({ color: 0x556b2f })),
        coin_greek: () => new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.02, 24), new THREE.MeshStandardMaterial({ color: 0xc0c0c0, metalness: 0.9 })),
        dragon: () => new THREE.Mesh(new THREE.TorusKnotGeometry(0.12, 0.04, 64, 8), new THREE.MeshStandardMaterial({ color: 0xff4500 })),
        pagoda: () => new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.4, 6), new THREE.MeshStandardMaterial({ color: 0x8b0000 })),
        terracotta: () => new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.4, 8), new THREE.MeshStandardMaterial({ color: 0xcd853f })),
        jade: () => {
            const group = new THREE.Group();
            const jadeMat = new THREE.MeshStandardMaterial({ 
                color: 0x00a86b, 
                roughness: 0.3,
                metalness: 0.1
            });
            // Main jade piece
            const main = new THREE.Mesh(new THREE.OctahedronGeometry(0.12), jadeMat);
            main.scale.set(1, 1.3, 0.6);
            group.add(main);
            // Small accent
            const accent = new THREE.Mesh(new THREE.OctahedronGeometry(0.05), jadeMat);
            accent.position.set(0.08, 0.1, 0);
            group.add(accent);
            return group;
        },
        lantern: () => new THREE.Mesh(new THREE.SphereGeometry(0.15, 8, 8), new THREE.MeshStandardMaterial({ color: 0xff0000, emissive: 0x330000 })),
        aztec_calendar: () => new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.25, 0.05, 32), new THREE.MeshStandardMaterial({ color: 0x8b7355 })),
        pyramid_mayan: () => new THREE.Mesh(new THREE.ConeGeometry(0.25, 0.35, 4), new THREE.MeshStandardMaterial({ color: 0xa0522d })),
        jaguar: () => new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, 0.12), new THREE.MeshStandardMaterial({ color: 0xffa500 })),
        maize: () => new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.25, 8), new THREE.MeshStandardMaterial({ color: 0xffd700 })),
        obsidian: () => new THREE.Mesh(new THREE.OctahedronGeometry(0.15), new THREE.MeshStandardMaterial({ color: 0x1a1a1a, metalness: 0.9 })),
        torii: () => new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.3, 0.05), new THREE.MeshStandardMaterial({ color: 0xff0000 })),
        samurai_helmet: () => new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), new THREE.MeshStandardMaterial({ color: 0x2f2f2f, metalness: 0.9 })),
        katana: () => new THREE.Mesh(new THREE.BoxGeometry(0.02, 0.4, 0.01), new THREE.MeshStandardMaterial({ color: 0xc0c0c0, metalness: 1 })),
        cherry_blossom: () => new THREE.Mesh(new THREE.IcosahedronGeometry(0.12), new THREE.MeshStandardMaterial({ color: 0xffb7c5 })),
        daruma: () => new THREE.Mesh(new THREE.SphereGeometry(0.15, 12, 12), new THREE.MeshStandardMaterial({ color: 0xff0000 }))
    };

    const createFunc = artifacts[type];
    if (createFunc) {
        const mesh = createFunc();
        mesh.castShadow = true;
        return mesh;
    }

    return new THREE.Mesh(
        new THREE.BoxGeometry(0.2, 0.2, 0.2),
        new THREE.MeshStandardMaterial({ color: 0x888888 })
    );
}

// ============================================
// DEBUG MENU
// ============================================

function setupDebugMenu() {
    const debugToggle = document.getElementById('debug-toggle');
    const debugMenu = document.getElementById('debug-menu');
    const countryList = document.getElementById('debug-country-list');
    const wallhackToggle = document.getElementById('wallhack-toggle');

    // Toggle debug menu
    debugToggle.addEventListener('click', () => {
        debugMenu.classList.toggle('show');
    });

    // Populate country buttons
    COUNTRIES.forEach((country, index) => {
        const btn = document.createElement('button');
        btn.className = 'debug-country-btn';
        btn.textContent = `${index + 1}. ${country.name}`;
        btn.dataset.countryIndex = index;
        btn.addEventListener('click', () => loadCountryForDebug(index));
        countryList.appendChild(btn);
    });

    // Wallhack toggle
    wallhackToggle.addEventListener('change', (e) => {
        wallhackEnabled = e.target.checked;
        updateWallhackMarkers();
    });

    // Close menu when clicking outside
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#debug-panel')) {
            debugMenu.classList.remove('show');
        }
    });
}

async function loadCountryForDebug(countryIndex) {
    const debugMenu = document.getElementById('debug-menu');
    debugMenu.classList.remove('show');

    // Update active button
    document.querySelectorAll('.debug-country-btn').forEach((btn, i) => {
        btn.classList.toggle('active', i === countryIndex);
    });

    // Reset game state
    artifactsFound = 0;

    // Remove old particles
    const toRemove = [];
    scene.traverse(obj => {
        if (obj.userData.isParticle) toRemove.push(obj);
    });
    toRemove.forEach(p => {
        scene.remove(p);
        if (p.geometry) p.geometry.dispose();
        if (p.material) p.material.dispose();
    });

    // Remove old artifacts
    artifacts.forEach(a => {
        scene.remove(a.mesh);
    });
    artifacts = [];

    // Load selected country
    currentCountry = COUNTRIES[countryIndex];
    console.log(`[DEBUG] Loading country: ${currentCountry.name}`);

    // Create platform and artifacts
    createDigPlatform(currentCountry);
    await placeArtifacts(currentCountry);

    // Reset UI
    document.getElementById('guess-btn').style.display = 'block';
    document.getElementById('next-round-btn').style.display = 'none';
    document.getElementById('country-input').value = '';
    updateUI();

    // Show confirmation
    const message = document.getElementById('message');
    message.textContent = `Testing: ${currentCountry.name}`;
    message.className = 'show';
    setTimeout(() => message.classList.remove('show'), 1500);

    // Reset camera
    camera.position.set(0, 6, 8);
    controls.target.set(0, 1, 0);

    // Update wallhack if enabled
    if (wallhackEnabled) {
        updateWallhackMarkers();
    }
}

function updateWallhackMarkers() {
    const TERRAIN_HEIGHT = 1.0;
    
    // Remove existing markers
    wallhackMarkers.forEach(marker => {
        scene.remove(marker);
        if (marker.geometry) marker.geometry.dispose();
        if (marker.material) marker.material.dispose();
    });
    wallhackMarkers = [];

    if (!wallhackEnabled) return;

    // Create markers for each hidden artifact
    artifacts.forEach((artifact, index) => {
        if (artifact.revealed) return;

        // Glowing ring marker on top of terrain surface
        const ringGeo = new THREE.RingGeometry(0.25, 0.35, 32);
        const ringMat = new THREE.MeshBasicMaterial({
            color: 0xff00ff,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.8
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.position.set(artifact.position.x, TERRAIN_HEIGHT + 0.1, artifact.position.y);
        ring.rotation.x = -Math.PI / 2;
        ring.userData.isWallhackMarker = true;
        scene.add(ring);
        wallhackMarkers.push(ring);

        // Vertical beam going down to show depth
        const beamHeight = artifact.revealDepth + 0.5;
        const beamGeo = new THREE.CylinderGeometry(0.03, 0.03, beamHeight, 8);
        const beamMat = new THREE.MeshBasicMaterial({
            color: 0xff00ff,
            transparent: true,
            opacity: 0.4
        });
        const beam = new THREE.Mesh(beamGeo, beamMat);
        beam.position.set(artifact.position.x, TERRAIN_HEIGHT - beamHeight / 2, artifact.position.y);
        beam.userData.isWallhackMarker = true;
        scene.add(beam);
        wallhackMarkers.push(beam);

        // Depth label (small sphere at artifact location)
        const sphereGeo = new THREE.SphereGeometry(0.1, 16, 16);
        const sphereMat = new THREE.MeshBasicMaterial({
            color: 0x00ffff,
            transparent: true,
            opacity: 0.9
        });
        const sphere = new THREE.Mesh(sphereGeo, sphereMat);
        sphere.position.set(artifact.position.x, TERRAIN_HEIGHT - artifact.revealDepth, artifact.position.y);
        sphere.userData.isWallhackMarker = true;
        scene.add(sphere);
        wallhackMarkers.push(sphere);
    });

    console.log(`[DEBUG] Wallhack: showing ${wallhackMarkers.length / 3} artifact locations`);
}

// ============================================
// UI SYSTEM
// ============================================

function setupUI() {
    document.getElementById('guess-btn').addEventListener('click', makeGuess);
    document.getElementById('next-round-btn').addEventListener('click', startNewRound);

    // Debug menu setup
    setupDebugMenu();

    const input = document.getElementById('country-input');
    const autocomplete = document.getElementById('autocomplete');

    input.addEventListener('keyup', (e) => {
        if (e.key === 'Enter') {
            makeGuess();
            return;
        }

        const value = input.value.toLowerCase();
        if (value.length < 2) {
            autocomplete.classList.remove('show');
            return;
        }

        const matches = ALL_COUNTRIES.filter(c =>
            c.toLowerCase().includes(value)
        ).slice(0, 5);

        if (matches.length > 0) {
            autocomplete.innerHTML = matches.map(m =>
                `<div class="autocomplete-item">${m}</div>`
            ).join('');
            autocomplete.classList.add('show');

            autocomplete.querySelectorAll('.autocomplete-item').forEach(item => {
                item.addEventListener('click', () => {
                    input.value = item.textContent;
                    autocomplete.classList.remove('show');
                });
            });
        } else {
            autocomplete.classList.remove('show');
        }
    });

    input.addEventListener('blur', () => {
        setTimeout(() => autocomplete.classList.remove('show'), 200);
    });
}

function updateUI() {
    document.getElementById('artifacts-found').textContent =
        `Artifacts: ${artifactsFound}/${totalArtifacts}`;
    document.getElementById('points-value').textContent = getPointsForCurrentState();
}

function getPointsForCurrentState() {
    if (artifactsFound <= 1) return 500;
    if (artifactsFound === 2) return 400;
    if (artifactsFound === 3) return 300;
    if (artifactsFound === 4) return 200;
    return 100;
}

function makeGuess() {
    const input = document.getElementById('country-input');
    const guess = input.value.trim().toLowerCase();
    const correct = currentCountry.name.toLowerCase();
    const message = document.getElementById('message');

    if (guess === correct) {
        const points = getPointsForCurrentState();
        score += points;
        message.textContent = `CORRECT! +${points}`;
        message.className = 'correct show';
        document.getElementById('score-value').textContent = score;
        document.getElementById('guess-btn').style.display = 'none';
        document.getElementById('next-round-btn').style.display = 'block';
    } else {
        const penalty = artifactsFound < 5 ? 100 : 0;
        score = Math.max(0, score - penalty);
        message.textContent = `WRONG! -${penalty}`;
        message.className = 'wrong show';
        document.getElementById('score-value').textContent = score;
    }

    setTimeout(() => message.classList.remove('show'), 2000);
    input.value = '';
}

// ============================================
// GAME FLOW
// ============================================

async function startNewRound() {
    artifactsFound = 0;

    // Remove old particles
    const toRemove = [];
    scene.traverse(obj => {
        if (obj.userData.isParticle) toRemove.push(obj);
    });
    toRemove.forEach(p => {
        scene.remove(p);
        if (p.geometry) p.geometry.dispose();
        if (p.material) p.material.dispose();
    });

    // Remove old artifacts
    artifacts.forEach(a => {
        scene.remove(a.mesh);
    });
    artifacts = [];

    // Clear wallhack markers
    wallhackMarkers.forEach(marker => {
        scene.remove(marker);
        if (marker.geometry) marker.geometry.dispose();
        if (marker.material) marker.material.dispose();
    });
    wallhackMarkers = [];

    // Pick random country
    currentCountry = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];

    // Create platform and artifacts
    createDigPlatform(currentCountry);
    await placeArtifacts(currentCountry);

    // Reset UI
    document.getElementById('guess-btn').style.display = 'block';
    document.getElementById('next-round-btn').style.display = 'none';
    document.getElementById('country-input').value = '';
    updateUI();

    // Reset camera
    camera.position.set(0, 6, 8);
    controls.target.set(0, 1, 0);

    // Update wallhack if enabled
    if (wallhackEnabled) {
        updateWallhackMarkers();
    }
}

// ============================================
// RENDER LOOP
// ============================================

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

// ============================================
// START
// ============================================

init();
