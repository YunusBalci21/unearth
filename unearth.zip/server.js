// ============================================
// MULTIPLAYER SERVER - Socket.io based
// ============================================
// 
// Run: node server.js
// Then open http://localhost:3000
//
// ============================================

import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const server = createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*",
        methods: ["GET", "POST"]
    }
});

// Serve static files
app.use(express.static(__dirname));

// ============================================
// GAME STATE
// ============================================

const rooms = new Map();
const playerRooms = new Map();

const COUNTRIES = [
    { name: 'Egypt', artifacts: ['pyramid', 'sphinx', 'ankh', 'scarab', 'pharaoh_mask'] },
    { name: 'Greece', artifacts: ['column', 'amphora', 'helmet', 'olive_branch', 'coin_greek'] },
    { name: 'China', artifacts: ['dragon', 'pagoda', 'terracotta', 'jade', 'lantern'] },
    { name: 'Mexico', artifacts: ['aztec_calendar', 'pyramid_mayan', 'jaguar', 'maize', 'obsidian'] },
    { name: 'Japan', artifacts: ['torii', 'samurai_helmet', 'katana', 'cherry_blossom', 'daruma'] }
];

function generateRoomCode() {
    return Math.random().toString(36).substring(2, 8).toUpperCase();
}

function createRoom(hostId, hostName) {
    const code = generateRoomCode();
    const room = {
        code,
        host: hostId,
        players: new Map(),
        state: 'waiting', // waiting, playing, results
        currentCountry: null,
        round: 0,
        maxRounds: 5,
        digSpots: [],
        settings: {
            maxPlayers: 8,
            roundTime: 60,
            artifactsPerRound: 5
        }
    };
    
    room.players.set(hostId, {
        id: hostId,
        name: hostName,
        score: 0,
        artifactsFound: 0,
        hasGuessed: false,
        isHost: true
    });
    
    rooms.set(code, room);
    playerRooms.set(hostId, code);
    
    return room;
}

function joinRoom(code, playerId, playerName) {
    const room = rooms.get(code);
    if (!room) return { error: 'Room not found' };
    if (room.state !== 'waiting') return { error: 'Game already in progress' };
    if (room.players.size >= room.settings.maxPlayers) return { error: 'Room is full' };
    
    room.players.set(playerId, {
        id: playerId,
        name: playerName,
        score: 0,
        artifactsFound: 0,
        hasGuessed: false,
        isHost: false
    });
    
    playerRooms.set(playerId, code);
    
    return { room };
}

function startRound(room) {
    room.round++;
    room.state = 'playing';
    room.currentCountry = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
    
    // Generate dig spot positions (same for all players)
    room.digSpots = generateDigSpots(5);
    
    // Reset player round state
    room.players.forEach(player => {
        player.artifactsFound = 0;
        player.hasGuessed = false;
    });
    
    return {
        round: room.round,
        terrain: room.currentCountry.name, // Client uses this to set terrain color
        digSpots: room.digSpots,
        artifacts: room.currentCountry.artifacts
    };
}

function generateDigSpots(count) {
    const spots = [];
    const minDistance = 3;
    
    for (let i = 0; i < count; i++) {
        let pos;
        let attempts = 0;
        
        do {
            const angle = Math.random() * Math.PI * 2;
            const r = Math.random() * 7;
            pos = {
                x: Math.cos(angle) * r,
                z: Math.sin(angle) * r
            };
            attempts++;
        } while (
            spots.some(s => 
                Math.sqrt(Math.pow(s.x - pos.x, 2) + Math.pow(s.z - pos.z, 2)) < minDistance
            ) && attempts < 50
        );
        
        spots.push({ ...pos, index: i, dugBy: null });
    }
    
    return spots;
}

function handleDig(room, playerId, spotIndex) {
    const spot = room.digSpots[spotIndex];
    if (!spot || spot.dugBy) return null;
    
    spot.dugBy = playerId;
    
    const player = room.players.get(playerId);
    if (player) {
        player.artifactsFound++;
    }
    
    return {
        spotIndex,
        playerId,
        playerName: player?.name,
        artifactType: room.currentCountry.artifacts[spotIndex]
    };
}

function handleGuess(room, playerId, guess) {
    const player = room.players.get(playerId);
    if (!player || player.hasGuessed) return null;
    
    player.hasGuessed = true;
    const correct = guess.toLowerCase() === room.currentCountry.name.toLowerCase();
    
    if (correct) {
        // Points based on how many artifacts they personally found
        const basePoints = 500 - (player.artifactsFound * 100);
        player.score += Math.max(basePoints, 100);
    }
    
    // Check if all players have guessed
    const allGuessed = Array.from(room.players.values()).every(p => p.hasGuessed);
    
    return {
        playerId,
        playerName: player.name,
        correct,
        newScore: player.score,
        roundOver: allGuessed,
        correctAnswer: allGuessed ? room.currentCountry.name : null
    };
}

function getLeaderboard(room) {
    return Array.from(room.players.values())
        .map(p => ({ name: p.name, score: p.score }))
        .sort((a, b) => b.score - a.score);
}

// ============================================
// SOCKET.IO EVENTS
// ============================================

io.on('connection', (socket) => {
    console.log(`Player connected: ${socket.id}`);
    
    // Create room
    socket.on('create-room', (playerName, callback) => {
        const room = createRoom(socket.id, playerName);
        socket.join(room.code);
        callback({ 
            success: true, 
            roomCode: room.code,
            players: Array.from(room.players.values())
        });
    });
    
    // Join room
    socket.on('join-room', (data, callback) => {
        const { roomCode, playerName } = data;
        const result = joinRoom(roomCode.toUpperCase(), socket.id, playerName);
        
        if (result.error) {
            callback({ success: false, error: result.error });
            return;
        }
        
        socket.join(roomCode);
        
        // Notify others
        socket.to(roomCode).emit('player-joined', {
            playerId: socket.id,
            playerName,
            players: Array.from(result.room.players.values())
        });
        
        callback({
            success: true,
            roomCode,
            players: Array.from(result.room.players.values())
        });
    });
    
    // Start game (host only)
    socket.on('start-game', (callback) => {
        const roomCode = playerRooms.get(socket.id);
        const room = rooms.get(roomCode);
        
        if (!room || room.host !== socket.id) {
            callback({ success: false, error: 'Not authorized' });
            return;
        }
        
        if (room.players.size < 1) {
            callback({ success: false, error: 'Need at least 1 player' });
            return;
        }
        
        const roundData = startRound(room);
        io.to(roomCode).emit('round-start', roundData);
        callback({ success: true });
    });
    
    // Player digs
    socket.on('dig', (spotIndex) => {
        const roomCode = playerRooms.get(socket.id);
        const room = rooms.get(roomCode);
        
        if (!room || room.state !== 'playing') return;
        
        const result = handleDig(room, socket.id, spotIndex);
        if (result) {
            io.to(roomCode).emit('artifact-revealed', result);
        }
    });
    
    // Player guesses
    socket.on('guess', (guess, callback) => {
        const roomCode = playerRooms.get(socket.id);
        const room = rooms.get(roomCode);
        
        if (!room || room.state !== 'playing') {
            callback({ success: false });
            return;
        }
        
        const result = handleGuess(room, socket.id, guess);
        if (!result) {
            callback({ success: false, error: 'Already guessed' });
            return;
        }
        
        // Notify all players of the guess result
        io.to(roomCode).emit('guess-result', result);
        
        callback({ 
            success: true, 
            correct: result.correct,
            newScore: result.newScore
        });
        
        // If round is over, send leaderboard and start next round
        if (result.roundOver) {
            const leaderboard = getLeaderboard(room);
            io.to(roomCode).emit('round-end', {
                correctAnswer: room.currentCountry.name,
                leaderboard
            });
            
            // Check if game is over
            if (room.round >= room.maxRounds) {
                room.state = 'results';
                io.to(roomCode).emit('game-over', { leaderboard });
            } else {
                // Auto-start next round after delay
                setTimeout(() => {
                    if (room.state !== 'results') {
                        const roundData = startRound(room);
                        io.to(roomCode).emit('round-start', roundData);
                    }
                }, 5000);
            }
        }
    });
    
    // Request next round (for when not all have guessed but want to proceed)
    socket.on('force-next-round', () => {
        const roomCode = playerRooms.get(socket.id);
        const room = rooms.get(roomCode);
        
        if (!room || room.host !== socket.id) return;
        
        if (room.round >= room.maxRounds) {
            room.state = 'results';
            const leaderboard = getLeaderboard(room);
            io.to(roomCode).emit('game-over', { leaderboard });
        } else {
            const roundData = startRound(room);
            io.to(roomCode).emit('round-start', roundData);
        }
    });
    
    // Disconnect handling
    socket.on('disconnect', () => {
        const roomCode = playerRooms.get(socket.id);
        
        if (roomCode) {
            const room = rooms.get(roomCode);
            if (room) {
                room.players.delete(socket.id);
                
                // If host left, assign new host or delete room
                if (room.host === socket.id) {
                    const remaining = Array.from(room.players.keys());
                    if (remaining.length > 0) {
                        room.host = remaining[0];
                        room.players.get(room.host).isHost = true;
                    } else {
                        rooms.delete(roomCode);
                    }
                }
                
                io.to(roomCode).emit('player-left', {
                    playerId: socket.id,
                    players: Array.from(room.players.values())
                });
            }
            
            playerRooms.delete(socket.id);
        }
        
        console.log(`Player disconnected: ${socket.id}`);
    });
});

// ============================================
// START SERVER
// ============================================

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
